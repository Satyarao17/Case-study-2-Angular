export interface Course
{
            courseName:string;
            courseDuration:string;
}